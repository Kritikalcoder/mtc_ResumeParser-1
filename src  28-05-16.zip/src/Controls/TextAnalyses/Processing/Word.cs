﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
//using System.Web.Script.Serialization;

namespace Gma.CodeCloud.Controls.TextAnalyses.Processing
{
    [Serializable]
    [KnownType(typeof(IWord))]
    [DataContract]
    public struct Word : IWord
    {
        [DataMember]
        public string Text { get; private set; }
        [DataMember]
        public int Occurrences { get; private set; }

        public Word(KeyValuePair<string, int> textOccurrencesPair)
            : this(textOccurrencesPair.Key, textOccurrencesPair.Value)
        {
        }

        public Word(string text, int occurrences)
            : this()
        {
            Text = text;
            Occurrences = occurrences;
        }

        public int CompareTo(IWord other)
        {
            return this.Occurrences - other.Occurrences;
        }

        public string GetCaption()
        {
            return string.Format("{0} - occurrences", Occurrences);
        }

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            throw new NotImplementedException();
        }
    }
}