﻿using System;
using System.Collections.Generic;
using Gma.CodeCloud.Controls.TextAnalyses.Processing;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using System.IO;
using System.Windows.Forms;


namespace PersistenceLibrary
{
    public class FilePersistor : IWordsWriter
    {
        bool IWordsWriter.WriteWords(IEnumerable<IWord> wordsToWrite)
        {
            throw new NotImplementedException();
        }

        public static bool WriteWords(IEnumerable<IWord> wordsToWrite)
        {
            var serializer = new JavaScriptSerializer();
            StreamWriter sw = new StreamWriter("test_this.txt");
            try
            {
                foreach (IWord word in wordsToWrite)
                {
                    string output = serializer.Serialize(word);
                    sw.WriteLine(output);
                }
                sw.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Could not serialize!");
                return false;
            }

            try
            {
                JsonSerializerSettings settings = new JsonSerializerSettings
                {
                    TypeNameHandling = TypeNameHandling.Auto
                };
                StreamReader sr = new StreamReader("test_this.txt");
                sw = new StreamWriter("testout.txt");
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    IEnumerable<Word> m_words = JsonConvert.DeserializeObject<IEnumerable<Word>>(line, settings);
                    foreach (Word word in m_words)
                    {
                        sw.Write(word.Text + "    " + word.Occurrences + ",   ");
                    }
                    sw.WriteLine();
                }
                sw.Close();
                sr.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Could not deserialise!");
                return false;
            }
            MessageBox.Show("File has been saved!");
            return true;
        }
    }
}


//this is for without grouped by stemmer
/*StreamWriter sw = new StreamWriter("test_this.txt");
JsonSerializerSettings settings = new JsonSerializerSettings
{
    TypeNameHandling = TypeNameHandling.Auto
};
string strJson;
foreach (IWord word in cloudControl.WeightedWords)
{
    strJson = JsonConvert.SerializeObject(word, settings);
    sw.WriteLine(strJson);
}
sw.Close();

StreamReader sr = new StreamReader("test_this.txt");
sw = new StreamWriter("testout.txt");
string line;
while((line=sr.ReadLine())!=null)
{
    Word m_words = JsonConvert.DeserializeObject<Word>(line, settings);
    sw.Write(m_words.Text + "    " + m_words.Occurrences);
    sw.WriteLine();
}
sw.Close();*/




//serialize
/*try
{
    using (FileStream writerFileStream = new FileStream("test_this.txt", FileMode.OpenOrCreate, FileAccess.Write))
    {
        //foreach(IWord word in cloudControl.WeightedWords)
        //{
            this.formatter.Serialize(writerFileStream, cloudControl.WeightedWords);
        //}
        writerFileStream.Close();
    }
}
catch (Exception)
{
    Console.WriteLine("unable to do this!");
}*/

/*try
{
    FileStream readerFileStream = new FileStream("test_this.txt", FileMode.Open, FileAccess.Read);
    readerFileStream.Position = 0;
    readerFileStream.Seek(0, SeekOrigin.Begin);
    m_words = (IEnumerable<IWord>) this.formatter.Deserialize(readerFileStream);
    /*StreamWriter sw = new StreamWriter("trial_write.txt");
    foreach (IWord word in m_words)
    {
            sw.Write(word.Text);
            sw.Write(word.Occurrences);
            sw.WriteLine();
    }
    sw.Close();
}
catch (Exception e)
{
    StreamWriter sw = new StreamWriter("trial_fail.txt");
    sw.Write(e.Message);
    sw.Close();
}*/


//datacontract
/*FileStream fs = new FileStream("test_this.txt",FileMode.OpenOrCreate);
DataContractJsonSerializer ser = new DataContractJsonSerializer(typeof(Word));
foreach(IWord word in cloudControl.WeightedWords)
{
    ser.WriteObject(fs, word);
}
ser.WriteObject(fs, cloudControl.WeightedWords);
fs.Close();*/
