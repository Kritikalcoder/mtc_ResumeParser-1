﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gma.CodeCloud.Controls.TextAnalyses.Processing;

namespace PersistenceLibrary
{
    public interface IWordsWriter
    {
        bool WriteWords(IEnumerable<IWord> wordsToWrite);
    }
}
