using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using Gma.CodeCloud.Controls.TextAnalyses;
using Gma.CodeCloud.Controls.TextAnalyses.Blacklist;
using Gma.CodeCloud.Controls.TextAnalyses.Blacklist.En;
using Gma.CodeCloud.Controls.TextAnalyses.Extractors;
using Gma.CodeCloud.Controls.TextAnalyses.Stemmers;
using Gma.CodeCloud.Controls.TextAnalyses.Stemmers.En;
using Gma.CodeCloud.Controls.TextAnalyses.Processing;
using PersistenceLibrary;

namespace ControlDemoApp
{
    internal static class ComponentFactory
    {
        public static IWordStemmer CreateWordStemmer(bool groupSameStemWords)
        {
            return groupSameStemWords
                       ? (IWordStemmer) new PorterStemmer()
                       : new NullStemmer();
        }

        public static IBlacklist CreateBlacklist(bool excludeEnglishCommonWords)
        {
            return excludeEnglishCommonWords
                       ? (IBlacklist) new CommonWords()
                       : new NullBlacklist();
        }

        public static IEnumerable<string> CreateExtractor(InputType inputType, string input, IProgressIndicator progress)
        {
            switch (inputType)
            {
                case InputType.File:
                    input = input.Replace(@"\", "\\");
                    FileInfo fileInfo = new FileInfo(input);
                    return new FileExtractor(fileInfo, progress);

                case InputType.Uri:
                    Uri uri = new Uri(input);
                    return new UriExtractor(uri, progress);

                default:
                    return new StringExtractor(input, progress);
            }
        }

        public static IProgressIndicator CreateProgressBar(InputType inputType, ProgressBar progressBar)
        {
            return 
                inputType==InputType.String ? 
                                                new ProgressBarWrapper(progressBar) : 
                                                                                        new InfiniteProgressBarWrapper(progressBar);
        }

        public static InputType DetectInputType(string input)
        {
            if (input.Length < 0x200)
            {
                if (input.StartsWith("http", true, CultureInfo.InvariantCulture))
                {
                    return InputType.Uri;
                }
                if (File.Exists(input))
                {
                    return InputType.File;
                }
            }
            return InputType.String;
        }
        
        public static PersistenceType DetectPersistType(int selectedIndex)
        {
            if (selectedIndex == 0)
            {
                return PersistenceType.File;
            }
            else if (selectedIndex == 1)
            {
                return PersistenceType.Sql;
            }
            else
            {
                return PersistenceType.Redis;
            }
        }

        public static bool Persist(PersistenceType persistType, IEnumerable<IWord> wordsToWrite)
        {
            switch (persistType)
            {
                case PersistenceType.File:
                    return FilePersistor.WriteWords(wordsToWrite);

                case PersistenceType.Sql:
                    return false;

                case PersistenceType.Redis:
                    return false;

                default:
                    return false;
            }
        }
    }
}