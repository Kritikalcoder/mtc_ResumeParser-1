﻿namespace ControlDemoApp
{
    internal enum PersistenceType
    {
        File,
        Sql,
        Redis
    }
}
