﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Linq;
using Gma.CodeCloud.Controls.Geometry;
using Gma.CodeCloud.Controls.TextAnalyses.Blacklist;
using Gma.CodeCloud.Controls.TextAnalyses.Blacklist.En;
using Gma.CodeCloud.Controls.TextAnalyses.Extractors;
using Gma.CodeCloud.Controls.TextAnalyses.Processing;
using Gma.CodeCloud.Controls.TextAnalyses.Stemmers;

namespace ControlDemoApp
{
    public partial class MainForm 
    {
        private const string s_BlacklistTxtFileName = "blacklist.txt";

        public MainForm()
        {
            InitializeComponent();
        }

        private void ButtonGoClick(object sender, EventArgs e)
        {
            IsRunning = true;

            //ProcessTextSimple();
            ProcessText();

            IsRunning = false;
        }

        private void ProcessTextSimple()
        {
            IsRunning = true;

            IBlacklist blacklist = new CommonWords();
            IProgressIndicator progress = new ProgressBarWrapper(progressBar);
            IEnumerable<string> terms = new StringExtractor(textBox.Text, progress);

            cloudControl.WeightedWords =
                terms
                    .Filter(blacklist)
                    .CountOccurences()
                    .SortByOccurences();

            IsRunning = false;
        }

        private void ProcessText()
        {
            IBlacklist blacklist = ComponentFactory.CreateBlacklist(checkBoxExcludeEnglishCommonWords.Checked);
            IBlacklist customBlacklist = CommonBlacklist.CreateFromTextFile(s_BlacklistTxtFileName);

            InputType inputType = ComponentFactory.DetectInputType(textBox.Text);
            IProgressIndicator progress = ComponentFactory.CreateProgressBar(inputType, progressBar);
            IEnumerable<string> terms = ComponentFactory.CreateExtractor(inputType, textBox.Text, progress);
            IWordStemmer stemmer = ComponentFactory.CreateWordStemmer(checkBoxGroupSameStemWords.Checked);

            IEnumerable<IWord> words = terms
                .Filter(blacklist)
                .Filter(customBlacklist)
                .CountOccurences();

            cloudControl.WeightedWords =
                words
                    .GroupByStem(stemmer)
                    .SortByOccurences()
                    .Cast<IWord>();
            PersistenceType persistType = ComponentFactory.DetectPersistType(choosePersistence.SelectedIndex);
            bool persist=ComponentFactory.Persist(persistType,cloudControl.WeightedWords);
            if (persist==false)
            {
                MessageBox.Show("Could not persist!");
            } 
    
            //for grouped by stem
            /*var serializer = new JavaScriptSerializer();
            StreamWriter sw = new StreamWriter("test_this.txt");
            try
            {
                foreach (IWord word in cloudControl.WeightedWords)
                {
                    string output = serializer.Serialize(word);
                    sw.WriteLine(output);
                }
                sw.Close();
            }
            catch(Exception)
            {
                MessageBox.Show("Could not save to file!");
            }

            try
            {
                JsonSerializerSettings settings = new JsonSerializerSettings
                {
                    TypeNameHandling = TypeNameHandling.Auto
                };
                StreamReader sr = new StreamReader("test_this.txt");
                sw = new StreamWriter("testout.txt");
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    m_words = JsonConvert.DeserializeObject<IEnumerable<Word>>(line, settings);
                    foreach (Word word in m_words)
                    {
                        sw.Write(word.Text + "    " + word.Occurrences + ",   ");
                    }
                    sw.WriteLine();
                }
                sw.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Could not save to file!");
            }*/
        }
        

        private bool IsRunning
        {
            set
            {
                buttonCancel.Enabled = value;
                buttonGo.Enabled = !value;
                progressBar.Value = 0;
            }
        }

        private void CancelClick(object sender, EventArgs e)
        {
            IsRunning = false;
        }

        private void CloudControlClick(object sender, EventArgs e)
        {
            LayoutItem itemUderMouse;
            Point mousePositionRelativeToControl = cloudControl.PointToClient(new Point(MousePosition.X, MousePosition.Y));
            if (!cloudControl.TryGetItemAtLocation(mousePositionRelativeToControl, out itemUderMouse))
            {
                return;
            }

            MessageBox.Show(
                itemUderMouse.Word.GetCaption(),
                string.Format("Statistics for word [{0}]", itemUderMouse.Word.Text));
        }

        private void LinkLabelEditCustomBlacklistLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (!File.Exists(s_BlacklistTxtFileName))
            {
                using(StreamWriter writer = File.CreateText(s_BlacklistTxtFileName))
                {
                    writer.WriteLine("IgnoreMeOne");
                    writer.WriteLine("IgnoreMeTwo");
                }
            }

            string absoluteFileName = Path.GetFullPath(s_BlacklistTxtFileName);
            Process.Start(absoluteFileName);
        }

        private void textBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void choosePersistence_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (choosePersistence.Text=="")
            {
                choosePersistence.Text="Choose how to save";
            }
        }
    }
}