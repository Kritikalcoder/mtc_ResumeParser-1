﻿namespace ControlDemoApp
{
    internal enum InputType
    {
        String,
        Uri,
        File
    }
}
