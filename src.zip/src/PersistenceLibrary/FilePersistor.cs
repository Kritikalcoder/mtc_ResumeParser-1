﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gma.CodeCloud.Controls.TextAnalyses.Processing;

namespace PersistenceLibrary
{
    class FilePersistor : IWordsWriter
    {
        bool IWordsWriter.WriteWords(IEnumerable<IWord> wordsToWrite)
        {
            throw new NotImplementedException();
        }
    }
}
